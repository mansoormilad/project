<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    public function receive_data (Request $request)
    {
            if($request->ajax()){

                return [
                    'name' => $request->person_name,
                    'last name' => $request->person_email
                ];
            }
            
    }

    public function get_button_text(Request $request){
        return \App\Models\Post::button_text();
    }
}
