<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use App\Models\User;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Str;

class UserLoginApi extends Controller
{

    function loginCheck(Request $request){

        if(User::credentialCheck($request)){
            $data = [
                'message'=> 'Welcome, successfully logged in',
                'username' => session('loggedUser'),
             ];
            return redirect('/dashboard')->with($data); 

        }else{
            return ['message'=>'0'];
        }
    }


    function loginGet(){

        return response()->json([
            'message'=> 'Welcome, Already Logged in users'
        ]);
    }
}
