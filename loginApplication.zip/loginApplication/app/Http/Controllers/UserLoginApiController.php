<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Hash;
use App\User;

use Illuminate\Contracts\Session\Session;

class UserLoginApi extends Controller
{

    function loginCheck(Request $request){

        if(User::credentialCheck($request)){

            return redirect()->route('getLogin', json_encode(array([
                        'message'=> 'Welcome, successfully logged in',
                        'username' => session('loggedUser'),
                        '_token' => str_random(60)
            ])));

        }else{
            return ['message', 'oops, please try again incorrect username and password'];
        }
    }


    function loginGet(){
        return response()->json([
            'message'=> 'Welcome, Already Logged in users'
        ]);
    }
}

