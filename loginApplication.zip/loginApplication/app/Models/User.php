<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Hash;
use session;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];



    public static function credentialCheck($credential){

        $validUser = [
            'username' => 'milad@gmail.com', 
            'password' => '$2y$10$g8lbJPqVQeLqr2asTxVY2uGMmS4qApclg7rXS7L3MZ1DLdALnLWiu', // password: mansoor@123
            'token'    => 'h9YQRPU7gH9dH1UnaCXxG83XX7UilmEwbTwEmyst'
        ];

        if($credential->username == $validUser['username'] && Hash::check($credential->password, $validUser['password']))
        {
            session(['loggedIn' =>  1, 'loggedUser' => $validUser['username']]);
            return true;

        }else{
            return false;

        }
    }

    public static function check_token($token){

        $validUser = [
            'username' => 'milad',
            'password' => '$2y$10$g8lbJPqVQeLqr2asTxVY2uGMmS4qApclg7rXS7L3MZ1DLdALnLWiu', // password: mansoor@123
            'token'    => 'h9YQRPU7gH9dH1UnaCXxG83XX7UilmEwbTwEmyst'
        ];

        if($token === $validUser['token']){
            return true;
        }else{
            return false;
        }
    }

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}
