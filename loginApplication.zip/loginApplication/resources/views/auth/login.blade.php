
@extends('layouts.app')
<link href="{{ asset('css/custom.css') }}" rel="stylesheet">
@section('content')
<body>
  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->

      <!-- Icon -->
      <div class="fadeIn first logo-images">

      </div>

      <!-- Login Form -->
      <div class="panel-body">
          <form class="form-horizontal" method="post" action="/api/loginApi" id="loginForm" >
              {{ csrf_field() }}

              <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                  <label for="email" class="col-md-4 control-label"> Address</label>

                  <div class="col-md-6">
                      <input id="email" type="email" class="form-control" name="username" value="{{ old('email') }}" required >

                      @if ($errors->has('email'))
                          <span class="help-block">
                              <strong>{{ $errors->first('email') }}</strong>
                          </span>
                      @endif
                  </div>
              </div>

              <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                  <label for="password" class="col-md-4 control-label">Password</label>

                  <div class="col-md-6">
                      <input id="password" type="password" class="form-control" name="password" required>

                      @if ($errors->has('password'))
                          <span class="help-block">
                              <strong>{{ $errors->first('password') }}</strong>
                          </span>
                      @endif
                  </div>
              </div>


              <div class="form-group align-left">
                  <div class="col-md-8 col-md-offset-4">
                      <button type="submit" id="btn-login" class="btn loginbtn btn-primary">
                          Login
                      </button>
                  </div>
              </div>
          </form>
      </div>

      <!-- Remind Passowrd -->
      <div id="formFooter">
        <a class="underlineHover" href="#">Forgot Password?</a>
      </div>

    </div>
  </div>
</body>

@endsection

@section('script')


    <script type="text/javascript">

        $(document).on('click', '#btn-login',function (e){
            // e.preventDefault();

            console.log('request send');
            let form = $("#loginForm").serialize();

            $.post('api/loginApi', form , function (data){
                console.log(data.message);
                if(data.message == 0){
                    alert('invalid username/password');
                }else{
                    $('#container').html(data);
                }
            });
        });

    </script>

@endsection
