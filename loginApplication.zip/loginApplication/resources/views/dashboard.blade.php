<!DOCTYPE html>
<html lang = "en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <title>Title Goes Here</title>
    </head>
    <body>
        @include ('menu')
        <!-- first component section -->

        <section>
          <div class="row">
             <div class="col-lg-2"></div>
             <div class="col-lg-4"><h6>Please click the button to  change color and click to previos color using JQuery</h6></div>
             <div class="col-lg-4"><h6>Please click button to change text button,Using ajax and jquery</h6></div>
             <div class="col-lg-2"></div>
           </div>

            <div class="row">
               <div class="col-lg-2"></div>
               <div class="col-lg-4"><button type="button" id="btn-color" class="btn btn-secondary btn-lg">JQuery Example</button></div>
               <div class="col-lg-4"><button type="button" id="btn-get-text" class="btn btn-primary btn-lg">Ajax Example</button></div>
               <div class="col-lg-2"></div>
             </div>
        </section>
        <hr class="m-5">
        <!-- end of first component section -->

        <!-- second component section -->

        <div class="flex-center position-ref full-height p-5">
            <form id="form-data" method="post" data-route="{{ route('postData') }}">
                {{ csrf_field() }}
                <div class="row">
                  <div class="col-lg-2">
                  </div>
                  <div class="col-lg-4">
                     <label class="form-label">Name: </label>
                     <input type="text" class="form-control" name="person_name">
                  </div>
                  <div class="col-lg-4">
                    <label class="form-label">Email:</label>
                    <input type="text" class="form-control" name="person_email">
                  </div>
                  <div class="col-lg-2">

                  </div>
                </div>
                <button type="submit" class="btn btn-primary align-center mt-3" style="margin-left:233px;">Button</button>
            </form>
        </div>
        <hr class="m-5">
        <!-- end of second component section -->

        <!-- third component section -->
        <div class="m-5">
          <h3>Static Table</h3>
          <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">First</th>
                <th scope="col">Last</th>
                <th scope="col">Handle</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td colspan="2">Larry the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
          </table>
      </div>




        <!-- end of third component section -->


    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" type="text/javascript"></script>

    <script type="text/javascript">

          $(function(){

              $('#form-data').submit(function(e){
                  var route = $('#form-data').data('route');
                  var form_data = $(this);
                  $.ajax({
                      type: 'POST',
                      url: route,
                      data: form_data.serialize(),
                      success: function(Response){
                          console.log(Response);
                      }
                  });
                  e.preventDefault();
              });

              $('#btn-color').click(function() {
                var clicks = $(this).data('clicks');
                if (clicks) {
                   $(this).css('background-color','#6c757d');
                } else {
                   $(this).css('background-color','blue');
                }
                $(this).data("clicks", !clicks);
              });

              $(document).on('click', '#btn-get-text',function (e){
                  e.preventDefault();
                  let form = $("#form-data").serialize();

                  $.post('{{route("button_text")}}', form , function (data){

                      $('#btn-get-text').html(data.button_text);

                  });
              });


          });

    </script>

</html>
