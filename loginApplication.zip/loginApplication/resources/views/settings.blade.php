<!DOCTYPE html>
<html lang = "en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <title>Title Goes Here</title>
    </head>
    <body>
        @include ('menu')
        <!-- first component section -->
        <div id="show-data" class="container">

        </div>
        <hr class="m-5">
        <!-- end of first component section -->



        <!-- second component section -->

        <div class="flex-center position-ref full-height ">
            <form id="form-data" method="post" data-route="{{ route('postData') }}">
                {{ csrf_field() }}
                <h5 style="margin-left:240px;">Form Data</h5>
                <div class="row">
                  <div class="col-lg-2">
                  </div>
                  <div class="col-lg-4">
                     <label class="form-label">User Name: </label>
                     <input type="text" class="form-control" name="person_name">
                  </div>
                  <div class="col-lg-4">
                    <label class="form-label">Email Number:</label>
                    <input type="text" class="form-control" name="person_email">
                  </div>
                  <div class="col-lg-2">

                  </div>
                </div>
                <button type="submit" class="btn btn-primary align-center mt-3" style="margin-left:238px;">Button</button>
            </form>
        </div>
        <hr class="m-5">
        <!-- end of second component section -->

        <!-- third component section -->
        <div class="m-5">
          <h3>Static Table</h3>
          <table class="table table-hover">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Age</th>
                <th scope="col">Username</th>
              </tr>
            </thead>
            <tbody>
              <tr id="df">
                <th scope="row">1</th>
                <td>Mansoor</td>
                <td>25</td>
                <td>@mansoor@123</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td colspan="2">Larry the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
          </table>
      </div>




        <!-- end of third component section -->


    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" type="text/javascript"></script>

    <script type="text/javascript">

          $(function(){

              $('#form-data').submit(function(e){
                  var route = $('#form-data').data('route');
                  var form_data = $(this);
                  $.ajax({
                      type: 'POST',
                      url: route,
                      data: form_data.serialize(),
                      success: function(Response){
                          console.log(Response);
                      }
                  });
                  e.preventDefault();
              });

              $('#btn-color').click(function() {
                var clicks = $(this).data('clicks');
                if (clicks) {
                   $(this).css('background-color','#6c757d');
                } else {
                   $(this).css('background-color','blue');
                }
                $(this).data("clicks", !clicks);
              });

              $(document).on('click', '#btn-get-text',function (e){
                  e.preventDefault();
                  let form = $("#form-data").serialize();

                  $.post('{{route("button_text")}}', form , function (data){

                      $('#btn-get-text').html(data.button_text);

                  });
              });

              $("#df").click(function() {

                    var $row = $(this).closest("tr"),       // Finds the closest row <tr>
                    $tds = $row.find("td");             // Finds all children <td> elements

                    $.each($tds, function() {               // Visits every single <td> element
                      let data = $(this).text();
                      $('#show-data').append(data);
                        console.log($(this).text());        // Prints out the text within the <td>
                    });
              });


          });

    </script>

</html>
