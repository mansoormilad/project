
<nav class ="navbar navbar-expand-lg navbar-dark bg-dark" style="margin-bottom:80px;">
    <div class="collapse navbar-collapse">
        <a href="/" class="navbar-brand">
            <!-- <img src="images/menu.png" alt="" class="d-inline-block align-top" height="30" width="30"> -->
            Fixed Navbar
        </a>

        <div class="navbar-nav">
            <a href="/dashboard" class="nav-item nav-link">Dashboard</a>
            <a href="/products" class="nav-item nav-link">Product</a>
            <a href="/settings" class="nav-item nav-link">Settings</a>
        </div>
    </div>
</nav>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/loginApplication/resources/views/menu.blade.php ENDPATH**/ ?>