<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" id="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Registration Form</div>

                    <div class="panel-body">
                        <form class="form-horizontal" method="post"  id="register-form" >
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group">
                                <label for="firstname" class="col-md-4 control-label">First name</label>
                                <div class="col-md-8">
                                    <input id="firstname" type="text" class="form-control" name="firstname" value="" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="lastname" class="col-md-4 control-label">Last name</label>
                                <div class="col-md-8">
                                    <input id="lastname" type="text" class="form-control" name="lastname" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4 col-md-offset-4">
                                    <button type="submit" id="btn-register" class="btn btn-primary">
                                    Register
                                    </button>
                                </div>
                            </div>
                        </form>

                        <form class="form-horizontal" method="post"  id="form-btn-text" >
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row">
                                <div class="col-md-4 col-md-offset-4">
                                    <button type="submit" id="btn-get-text" class="btn btn-success">
                                        Get Request
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-md-offset-2" id="get-requested-data"> </div>
            <div class="col-md-8 col-md-offset-2" id="post-requested-data"> </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


    <script type="text/javascript">

        $(document).on('click', '#btn-get-text',function (e){
            e.preventDefault();
            let form = $("#form-btn-text").serialize();

            $.post('<?php echo e(route("button_text")); ?>', form , function (data){

                $('#btn-get-text').html(data.button_text);

            });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/loginApplication/resources/views/products.blade.php ENDPATH**/ ?>